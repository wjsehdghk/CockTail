package com.kimnohjeon.bluecocktail;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    //This is a default proximity uuid of the RECO
    public static final String RECO_UUID = "24DDF411-8CF1-4407CD-E368DAF9C93E";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



    }

}
