package com.kimnohjeon.bluecocktail;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.kimnohjeon.bluecocktail.waveview.WaveView;

public class IntroActivity extends AppCompatActivity {

    private WaveView waveView;
    WaveHandler wHandler;
    int wavePosition = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        waveView = (WaveView) findViewById(R.id.wave_view);
        wHandler = new WaveHandler();

        ActionBar actionBar = getSupportActionBar();

        if (wavePosition == 100) {
            Intent intent = new Intent(IntroActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }

    }

    public void onStart() {
        super.onStart();
        waveView.setProgress(wavePosition);
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (wavePosition < 100) {
                        Thread.sleep(20);
                        Message msg = wHandler.obtainMessage();
                        wHandler.sendMessage(msg);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        thread1.start();
    }

    public class WaveHandler extends Handler {
        public void handleMessage(Message msg) {
            waveView.setProgress(wavePosition++);
            if(wavePosition == 100 ) {
                Intent intent = new Intent(IntroActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }

}
