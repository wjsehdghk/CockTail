package com.kimnohjeon.bluecocktail;

import android.content.Context;
import android.media.AudioManager;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Toast;

public class CoctailResionActivity extends AppCompatActivity {

    private AudioManager aManager ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coctail_resion);

        /*Button button = (Button)findViewById(R.id.button);
        Button ringerButton = (Button)findViewById(R.id.ringerButton);
        Button vibrationButton = (Button)findViewById(R.id.vibrationButton);
        Button muteButton = (Button)findViewById(R.id.muteButton);*/

        SeekBar brightnessSeekBar = (SeekBar)findViewById(R.id.brightnessSeekBar);
        brightnessSeekBar.setProgress(50);

        brightnessSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(progress > 10) {
                    WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.alpha = (float) progress / 100;
                    lp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    getWindow().setAttributes(lp);
                    Settings.System.putInt(getContentResolver(), "screen_brightness", progress);
                }

            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //선택 막대를 터치하고 드래그를 시작할 때 실행되는 메서드
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //선택이 완료했음을 표시하는 메서드

            }
        });
    }

    public void onButtonClicked(View v) {
        aManager = (AudioManager) getBaseContext().getSystemService(Context.AUDIO_SERVICE);
        Button btn = (Button)v;
        /*
        switch (btn.getId()) {
            case R.id.ringerButton:
                aManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                break;
            case R.id.vibrationButton:
                aManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
                break;
            case R.id.:
                aManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                break;
            default:
                Toast.makeText(this, "버튼이 아닙니다.",Toast.LENGTH_LONG).show();
                break;
        }
        */
        if(btn.getId() == R.id.ringerButton) {
            aManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
        }
        else if(btn.getId() == R.id.vibrationButton) {
            aManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
        }
        else if(btn.getId() == R.id.muteButton){
            aManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
        }
    }

}
