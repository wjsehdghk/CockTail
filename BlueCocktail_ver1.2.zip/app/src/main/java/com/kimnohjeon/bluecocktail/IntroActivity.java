package com.kimnohjeon.bluecocktail;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;

import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.kimnohjeon.bluecocktail.waveview.WaveView;

public class IntroActivity extends AppCompatActivity {

    private static final int REQUEST_ENABLE_BT = 1;

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    boolean isBluetoothEnabled = false;

    private WaveView waveView;
    int wavePosition = 0;
    WaveHandler wHandler;
    int waveMax = 40;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_intro);

        waveView = (WaveView) findViewById(R.id.wave_view);
        wHandler = new WaveHandler();


        ActionBar actionBar = getSupportActionBar();

        //If a user device turns off bluetooth, request to turn it on.
        // 사용자가 블루투스를 켜도록 요청
        mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = mBluetoothManager.getAdapter();

        if(mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBTIntent, REQUEST_ENABLE_BT);
        }
        else {
            isBluetoothEnabled = true;
            if(wavePosition == waveMax) {
                Intent intent = new Intent(IntroActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }

    public void onStart() {
        super.onStart();
        waveView.setProgress(wavePosition);
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (wavePosition < waveMax) {
                        Thread.sleep(50);
                        Message msg = wHandler.obtainMessage();
                        wHandler.sendMessage(msg);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        thread1.start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
            //If the request to turn on bluetooth is denied, the app will be finished.
            //사용자가 블루투스 요청을 허용하지 않았을 경우, 어플리케이션은 종료됩니다.
            finish();
            return;
        }
        else if (resultCode == Activity.RESULT_OK) {
            if(wavePosition >= waveMax) {
                Intent intent = new Intent(IntroActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
        else {
            isBluetoothEnabled = true;
            if(wavePosition == waveMax) {
                Intent intent = new Intent(IntroActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public class WaveHandler extends Handler {
        public void handleMessage(Message msg) {
            waveView.setProgress(wavePosition++);
            if(wavePosition == waveMax && isBluetoothEnabled) {
                Intent intent = new Intent(IntroActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }

}
