package com.kimnohjeon.bluecocktail.interfaces;

/**
 * Created by multimedia on 2016-03-21.
 */
public interface Resourceble {
    public int getImageRes();

    public String getName();
}
